<?php
$menuBtn = get_field('button-header', 'option');
wp_head();
?>


<header>
    <div class="wrapper">
        <div>
            <img src="<?= SVG_PATH ?>/logoApproved.svg" alt="logo">
        </div>
        <a class="main-button" href="<?= $menuBtn['url'] ?>" target="<?= $menuBtn['target'] ?>"><?= $menuBtn['title'] ?></a>
    </div>
</header>