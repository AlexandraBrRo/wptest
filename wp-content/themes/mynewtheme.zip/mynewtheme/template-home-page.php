<?php
/**
 * * Template name: Home page
 */
get_header();
?>

<?php
    $heroSection = get_field('hero_section');
    // var_dump($heroSection);
    $heroTitle = $heroSection['title'];
    $heroDescription = $heroSection['description'];
    $heroGreenButton = $heroSection['green_button'];
    $heroUrlLink = $heroSection['url_link'];
    $heroImage = $heroSection['image'];

    $heroTitleItem = $heroSection['title_item'];
    $heroTitlePart = $heroTitleItem['title_part_copy2'];
    $heroTitlePart2 = $heroTitleItem['title_part_copy3'];
  
?>

<div class="background-wrapper">
    <div class="wrapper">
        <div class="left-side">
            <h1 class="title"><?= $heroTitle ?></h1>
            <P class="description"><?= $heroDescription ?></P>
            <div class="buttons">
                <a class="main-button long-button" href="<?= $heroGreenButton['url'] ?>" target="<?= $heroGreenButton['target'] ?>"><?= $heroGreenButton['title'] ?></a>
                <a class="button-url" href="<?= $heroUrlLink['url']?>" target="<?= $heroUrlLink['target']?>"><?= $heroUrlLink['title'] ?></a>
            </div>
        </div>
        
        <div class="right-side">
            <div class="txt-img">
                <span><?=$heroTitleItem['title_part'] ?></span>
                <div class="line-txt"></div>
            </div>
            <div class="txt1-img">
                <span><?=$heroTitleItem['title_part_copy'] ?></span>
                <div class="line-txt"></div>
            </div>
            <div class="txt2-img">
                <span><?=$heroTitlePart['title_part'] ?></span>
                <div class="line-txt"></div>
                <p class="block-txt"><?=$heroTitlePart['info_text'] ?></p>
            </div>
            <div class="img-part">
                <img src="http://wptest/wp-content/uploads/2022/11/rectangle.png" alt="">
            </div>
            <div class="txt3-img txt-right">
                <span><?=$heroTitlePart2['title_part'] ?></span>
                <div class="line-txt"></div>
                <p class="block-txt move-txt"><?=$heroTitlePart2['info_text'] ?></p>
            </div>
        </div>
    </div>
</div>






